﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CentralDeUsuarios.UnitTests.Repositories
{
    /// <summary>
    /// Classe de teste para o repositório de usuários
    /// </summary>
    public class UsuarioRepositoryTest
    {
        [Fact(Skip = "Não implementado.")]
        public void TestCreate()
        {

        }

        [Fact(Skip = "Não implementado.")]
        public void TestUpdate()
        {

        }

        [Fact(Skip = "Não implementado.")]
        public void TestDelete()
        {

        }

        [Fact(Skip = "Não implementado.")]
        public void TestGetAll()
        {

        }

        [Fact(Skip = "Não implementado.")]
        public void TestGetById()
        {

        }

        [Fact(Skip = "Não implementado.")]
        public void TestGetByEmail()
        {

        }
    }
}
